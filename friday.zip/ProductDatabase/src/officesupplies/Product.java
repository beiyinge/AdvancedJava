package officesupplies;

public class Product implements java.io.Serializable, Comparable<Product> {
    
	private static final long serialVersionUID=1L;
	
    protected String id;                //  Unique key value for each product
    protected String description;
    protected String unitOfMeasure;
    protected double unitPrice;
    protected int    qtyOnHand;         //  Qty available to be shipped
    protected int    qtyOrdered;        //  Qty ordered, but not shipped

    public Product() { }

    public Product (String id, String description, String unitOfMeasure,
                double unitPrice, int qtyOnHand, int qtyOrdered) {


    }
    


    public String getId()            { return this.id; }
    public String getDescription()   { return this.description; }
    public String getUnitOfMeasure() { return this.unitOfMeasure;}
    public double getUnitPrice()     { return this.unitPrice;}
    public int    getQtyOnHand()     { return this.qtyOnHand; }
    public int    getQtyOrdered()    { return this.qtyOrdered; }

//    public void setId            (String str)   {  }
//    public void setDescription   (String str)   {  }
//    public void setUnitOfMeasure (String str)   {  }
//    public void setUnitPrice     (double price) {  }
//    public void setQtyOnHand     (int qty)      {  }
//    public void setQtyOrdered    (int qty)      {  }

    /**
    *   Add the specified amount (may be negative) to qty on hand
    *   and return the updated qty
    */
    

    
    public void setId(String id) {
		this.id = id;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public void setQtyOnHand(int qtyOnHand) {
		this.qtyOnHand = qtyOnHand;
	}

	public void setQtyOrdered(int qtyOrdered) {
		this.qtyOrdered = qtyOrdered;
	}
	
    public int updateQtyOnHand (int amt) {
    	return qtyOnHand + amt;
    }

	/**
    *   Add the specified amount (may be negative) to qty ordered
    *   and return the updated qty
    */
    
    public int updateQtyOrdered (int amt) {
    	return qtyOrdered + amt;
    }

	@Override
	public String toString() {
		return "Product [id=" + id + ", description=" + description + ", unitOfMeasure=" + unitOfMeasure
				+ ", unitPrice=" + unitPrice + ", qtyOnHand=" + qtyOnHand + ", qtyOrdered=" + qtyOrdered + "]";
	}

	@Override
	public int compareTo(Product o) {
		// TODO Auto-generated method stub
		return this.getId().compareTo(o.getId());
	}
	
    
    
    /**
    *   Return a string representation of all of the product data
    */

//    public String toString() {
//    	
//    }
    
    
}


