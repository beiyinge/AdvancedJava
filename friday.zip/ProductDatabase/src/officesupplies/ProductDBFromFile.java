package officesupplies;

import java.util.*;

import resources.ResourceLocator;

import java.io.*;
import java.util.logging.*;

/**
*   Product data is read from a file and stored as a HashMap.  The
*   entire file is read into the HashMap, and all requests for data
*   will come directly from the HashMap in memory, using the methods
*   inherited from the HashMap class (primarily the get() method).
*
*   The file is a "flat" file containing ASCII text.  The data file
*   provided for the project is called "products.txt".  Each record
*   corresponds to one product, and the fields are comma-separated.
*/

public class ProductDBFromFile extends HashMap<String, Product> implements Database {
    private static Logger log = Logger.getLogger("ProductDBFromFile");
 
    /* 
    *   Reads from the products.txt file supplied in the data directory     
    *   Opens the data file.  Reads each record and creates a Product
    *   object, then stores it in the hash map using the product id as
    *   the key and the Product object as the value.
    *
    *   (Hints:  Use String.split(",") to parse the records.  Use the put() 
    *            method of HashMap to store key/value pairs in the map.)
    *
    *   Returns false if any exceptions occur, otherwise true.
    */
    
    public boolean open () {
        boolean successFlag = true; //assume success
        try{
            //populate the hash map here
        	
        	Class c = ProductDBFromFile.class;
        	InputStream fis = ResourceLocator.class.getResourceAsStream("products.txt");
        	InputStreamReader isr = new InputStreamReader(fis);
        	BufferedReader br = new BufferedReader(isr);
        	String txt;
        	while (( txt = br.readLine()) != null) {
        		//parse product
        		//System.out.printf("line=%s",txt);
        		Product p = parseLine(txt);
        		this.put(p.id, p);
        		log.info("created a product");
        	}
        }catch(Exception e){
            successFlag = false;
            e.printStackTrace();
        }finally{
            // close any i/o classes used
        }
        return successFlag;
    }
    
    /**
    *   Saves the data in the HashMap back into the data file.
    *   For now, this method can simply return true as we won't
    *   be updating the product database in this project.
    */
    
    public boolean close() {
        return true;
    }
    
    private Product parseLine(String txt) {
    	Product p = new Product();
    	String[] str = txt.split(",");
    	p.setId(str[0]);
    	p.setDescription(str[1]);
    	p.setUnitOfMeasure(str[2]);
    	p.setUnitPrice(Double.valueOf(str[3]));
    	p.setQtyOnHand(Integer.valueOf(str[4]));
    	p.setQtyOrdered(Integer.valueOf(str[5]));
    	return p;
    }
}
