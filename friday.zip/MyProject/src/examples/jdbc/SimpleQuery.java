package examples.jdbc;
import java.sql.*;
public class SimpleQuery {
    public static void main(String args[]) {
        try {
            Connection con = DatabaseUtils.getDBConnection();
            // Create and send statement
            String query = "SELECT first_name, last_name, hire_date FROM Employee";
            Statement stmt = con.createStatement();
            ResultSet rslt = stmt.executeQuery(query);
            // Process data
            String firstName, lastName;
            java.util.Date hireDate;
            int pages;
            while (rslt.next()) {
                firstName = rslt.getString("first_name");
                lastName = rslt.getString("last_name");
                hireDate = rslt.getDate("hire_date");
                System.out.println(firstName + " " + lastName + " " + hireDate);
                    
            }
            // Cleanup
            rslt.close();
            stmt.close();
            con.close();
        } catch (SQLException sqle){
            System.out.println(sqle.getMessage());
        }
    }
}