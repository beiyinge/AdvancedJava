package examples.assertions;

public class AssertAsIdentifier {
    public static void main(String args[]){
        String assert = "test";
    }
}
