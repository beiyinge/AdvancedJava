package examples.networking;
import java.net.*;
import java.util.Date;
import java.io.*;
public class DayTimeClient {
    public static void main(String args[]) {
        //String host = "time.nist.gov";
    	//String host ="10.15.132.240";
    	String host ="10.15.132.173";
        try {
            if(args.length > 0)
                host = args[0];
            Socket s = new Socket(host, 9999);
            InputStream is = s.getInputStream();
            ObjectInputStream oos = new ObjectInputStream(is);
            
//            BufferedReader br = new BufferedReader(
//                    new InputStreamReader(is));
            System.out.println("Time at " +
                                host + " is");
            Date d = (Date)oos.readObject();
            System.out.println(d.getDate());
            oos.close();
            is.close();
            
//            String data;
//            while((data = br.readLine()) != null)
//                System.out.println(data);
//            br.close();
            s.close();
        }catch(IOException e) {
            System.out.println(e);
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}