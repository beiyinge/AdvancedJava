package mywork;

public enum EnumeratedAddress {
	HOME, WORK
	
}
