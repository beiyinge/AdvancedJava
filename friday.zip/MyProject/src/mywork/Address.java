package mywork;

public class Address {
    private String street;
    private String city;
    private String state;
    private String zipCode;
    private EnumeratedAddress type;
    
    public Address(String street, String city,
            String state, String zipcode) {
        this.street = street;
        this.city = city;
        this.state = state;
        this.zipCode = zipcode;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipcode() {
        return zipCode;
    }

    public void setZipcode(String zipcode) {
        this.zipCode = zipcode;
    }
    
    
    public EnumeratedAddress getType() {
		return type;
	}

	public void setType(EnumeratedAddress type) {
		this.type = type;
	}

	public String toString(){
        StringBuffer sb = new StringBuffer(64);
        sb.append(street).append('\n');
        sb.append(city).append(", ");
        sb.append(state).append(' ').append(zipCode);
        sb.append(" (").append(type).append(')');
        return sb.toString();
    }
}