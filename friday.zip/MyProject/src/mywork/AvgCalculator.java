package mywork;

public class AvgCalculator {
	public double average(int ... numbers ) {
		
		int sum = 0;
		for (int n : numbers) {
			sum = sum + n;
		}
		double avg = (double)sum / (numbers.length);
		return avg;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] numbers1 = {1,2,3,4,5,99};
		AvgCalculator c = new AvgCalculator();
		System.out.println("avg="+ c.average(numbers1));

	}

}
