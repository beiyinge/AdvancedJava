package instructor;

import java.util.Arrays;
import java.util.Comparator;

public class SampleLambdaStrings {
	
	
	
	public static void main(String[] args) {
		String fmt = "%35s %s%n";
		String names [] = {"Bob", "Sue", "billy", "Anthony", "alice", "Zoey"};
		Arrays.sort(names);
		System.out.printf(fmt, "Natural Sort:", Arrays.toString(names));
		
		//Lambda Expression
		Arrays.sort(names, (String s1, String s2) -> {
			return Integer.valueOf(s1.length()).compareTo(s2.length());
		});
		System.out.printf(fmt, "Lambda Expression by length:", Arrays.toString(names));
		
		//Removal of return and {}
		Arrays.sort(names, (s1, s2) -> 
			Integer.valueOf(s1.length()).compareTo(s2.length()));
		System.out.printf(fmt, "Simplified Lambda:", Arrays.toString(names));
		
		//Lambda invoking existing method
		Arrays.sort(names, (s1, s2) -> SampleLambdaStrings.compareByLength(s1, s2));
		System.out.printf(fmt, "Lambda invoking existing method:", Arrays.toString(names));
		
		//Replace Lambda with Method Reference
		Arrays.sort(names, SampleLambdaStrings::compareByLength);
		System.out.printf(fmt, "Method Reference:", Arrays.toString(names));	}
	
	public static int compareByLength(String s1, String s2) {
		return Integer.valueOf(s1.length()).compareTo(s2.length());
	}
	
	
}

