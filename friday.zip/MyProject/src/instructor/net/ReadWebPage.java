package instructor.net;
import java.net.*;

import examples.review.IOCleanupUtils;

import java.io.*;
public class ReadWebPage {
    public static void main(String args[]) {
    	InputStream  is = null;
        FileOutputStream fos =null;
        try {
            URL web = new URL("http://" + args[0]);
            String fileName = web.getFile();
            is = web.openStream();
            fos = new FileOutputStream(fileName);
            byte[] buffer = new byte[4096];
            int count;
            while ((count = is.read(buffer)) != -1) {
                fos.write(buffer, 0, count);
            }
        } catch(MalformedURLException e)  {
            System.out.println("Malformed");
        } catch(IOException e) {
            System.out.println("IOException");
        }finally {
        	IOCleanupUtils.cleanup(is);
        	IOCleanupUtils.cleanup(fos);
        }
    }
}