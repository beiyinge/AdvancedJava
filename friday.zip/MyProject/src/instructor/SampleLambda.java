package instructor;

import java.util.Arrays;
import java.util.Comparator;

public class SampleLambda {
	
	
	
	public static void main(String[] args) {
		String fmt = "%35s %s%n";
		String names [] = {"Bob", "Sue", "billy", "Anthony", "alice", "Zoey"};
		Arrays.sort(names);
		System.out.printf(fmt, "Natural Sort:", Arrays.toString(names));
		
		//Lambda Expression
		Arrays.sort(names, (Object o1, Object o2) -> {
			return Integer.valueOf(((String) o1).length()).compareTo(((String) o2).length());
		});
		System.out.printf(fmt, "Lambda Expression by length:", Arrays.toString(names));
		
		//Removal of return and {}
		Arrays.sort(names, (o1, o2) -> 
			Integer.valueOf(((String) o1).length()).compareTo(((String) o2).length()));
		System.out.printf(fmt, "Simplified Lambda:", Arrays.toString(names));
		
		//Lambda invoking existing method
		Arrays.sort(names, (o1, o2) -> SampleLambda.compareByLength(o1, o2));
		System.out.printf(fmt, "Lambda invoking existing method:", Arrays.toString(names));
		
		//Replace Lambda with Method Reference
		Arrays.sort(names, SampleLambda::compareByLength);
		System.out.printf(fmt, "Method Reference:", Arrays.toString(names));	}
	
	public static int compareByLength(Object o1, Object o2) {
		return Integer.valueOf(((String) o1).length()).compareTo(((String) o2).length());
	}
	
	
}

