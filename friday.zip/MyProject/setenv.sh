# SET Lab Specific Environment Variables
export LABDIR=~/advjavalabs
export SOURCE=$LABDIR/src
export CLASSES=$LABDIR/bin
export DOCS=$LABDIR/docs
# SET PATH and CLASSPATH Environment Variables
export JAVA_HOME=/usr/lib/jvm/java-14-openjdk-amd64
export CLASSPATH=$LABDIR/bin
