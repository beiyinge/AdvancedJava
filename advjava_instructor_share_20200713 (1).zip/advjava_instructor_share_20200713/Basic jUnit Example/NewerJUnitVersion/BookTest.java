import static org.junit.Assert.*;

import org.junit.Test;

public class BookTest {
	@Test
	public void roundPages() {
		Book b = new Book("Me", 26);
		b.roundPages();
		assertTrue(b.pages % 3 == 0);
	}
	
	@Test
	public void testTitle() {
		Book b = new Book("Something", 26);
		assertEquals("Something", b.title);
	}
}
