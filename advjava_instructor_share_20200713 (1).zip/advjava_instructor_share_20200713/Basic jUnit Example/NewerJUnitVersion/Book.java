public class Book {

	String title;
	int pages;

	Book(String t, int n) {
		title = (t == null) ? t : "none";
		pages = n;
	}

	// Round number of pages up
	// to be a multiple of three
	public void roundPages() {
		int extraPages = pages % 3;
		if (extraPages == 1) {
			pages += 1;
		} else if (extraPages == 2) {
			pages += 2;
		}
	}
}