import junit.framework.TestCase;

public class BookTest extends TestCase {
	public BookTest(String testName) {
		super(testName);
	}

	public void testRoundPages() {
		Book b = new Book("Me", 26);
		b.roundPages();
		assertTrue(b.pages % 3 == 0);
	}

	public void testTitle() {
		Book b = new Book("", 26);
		assertNotNull(b.title);
	}
}
