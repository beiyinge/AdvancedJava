package instructor.generics;

import java.util.*;

public class TestingGenerics {
	public static void main(String[] args) {
		ArrayList<Something> a = new ArrayList<Something>();
		Something s = new Something();
		SomethingElse se = new SomethingElse();
		a.add(s);
		a.add(se);
		anything(a);
		
		
		ArrayList<SomethingElse> other = new ArrayList<SomethingElse>();
		other.add(se);
		anything(other);
	}
	
	
	public static void anything(List<? extends Something> list) {
		
	}
	
}


class Something{
	
}

class SomethingElse extends Something{
	
}