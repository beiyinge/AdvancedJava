package instructor;

import java.util.Arrays;
import java.util.Comparator;

public class SampleInner {
	
	
	
	public static void main(String[] args) {
		String names [] = {"Bob", "Sue", "billy", "Anthony", "alice", "Zoey"};
		Arrays.sort(names);
		System.out.println(Arrays.toString(names));
		
		//Lambda Expression
		Arrays.sort(names, (o1, o2)  ->  { 
			return Integer.valueOf(o1.length()).compareTo(o2.length());   
		});
		
		//Lambda Expression
		Arrays.sort(names, (o1, o2)  -> Integer.valueOf(o1.length()).compareTo(o2.length()));
		
		//Lambda Expression
		Arrays.sort(names, (o1, o2)  -> SampleInner.compareByLength(o1, o2));
	
		// Method references
		Arrays.sort(names, SampleInner::compareByLength);
		
		
		System.out.println(Arrays.toString(names));
	}
	
	
	public static int compareByLength(String o1, String o2) {
		return Integer.valueOf(o1.length()).compareTo(o2.length());   
	}
	
	
}

