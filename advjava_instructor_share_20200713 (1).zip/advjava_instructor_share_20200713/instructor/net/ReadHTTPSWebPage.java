package instructor.net;
import java.net.*;
import java.io.*;
public class ReadHTTPSWebPage {
    public static void main(String args[]) {
        try {
        	DisableHTTPSValidation.disable();
            URL web = new URL("https://" + args[0]);
            InputStream  is = web.openStream();
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(is));
            String text;
            while((text = br.readLine()) != null)
                System.out.println(text);
            br.close();
        } catch(MalformedURLException e)  {
            System.out.println("Malformed");
        } catch(IOException e) {
            System.out.println("IOException");
        }
        catch(Exception e) {
            System.out.println("IOException");
        }
    }
}