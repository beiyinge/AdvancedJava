package instructor.jdbc;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import examples.jdbc.DatabaseUtils;
public class SimpleQuery {
    public static void main(String args[]) {
        try {
            Connection con = DatabaseUtils.getDBConnection();
            // Create and send statement
            String query = "SELECT first_name, last_name, hire_date " +
                           "FROM Employee";
            Statement stmt = con.createStatement();
            ResultSet rslt = stmt.executeQuery(query);
            
            // Process data
            String first_name,last_name, hire_date;
            ArrayList<String []> employees = new ArrayList<String []>();
            
            while (rslt.next()) {
            	String data [] = {rslt.getString("first_name"),
            			          rslt.getString("last_name"),
            			          rslt.getString("hire_date")};
            	employees.add(data);
            }
            // Cleanup
            rslt.close();
            stmt.close();
            con.close();
            
            
            ArrayList<String> first_names = new ArrayList<String>();
            employees.forEach((n) -> first_names.add(n[0]));
            
            
            
            int longest = first_names.stream()
            		           .map(String::length)
            		           .max(Integer::compare)
            		           .get();
            
            String fmt = "%-" + longest + "s %-16s %s%n";
            for (String employee [] : employees) {
            	System.out.printf(fmt, employee);
            }
            
            
            
        } catch (SQLException sqle){
            System.out.println(sqle.getMessage());
        }
    }
}