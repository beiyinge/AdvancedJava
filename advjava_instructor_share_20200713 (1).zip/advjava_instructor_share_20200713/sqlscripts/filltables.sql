DELETE FROM Employee;
INSERT INTO Employee (employee_id, first_name, last_name, phone, salary, bonus, gender, married, hire_date, team_id)
    VALUES (500, 'Morgan', 'Wilson', '2015556298', 50000, 10000, 'M', 'Y', '1990-06-10', 400),
           (501, 'Emily', 'Wilson', '2015556298', 50000, 10000, 'F', 'Y', '1995-01-01', 401),
           (502, 'Kim', 'Perkins', '4105557985', 40000, 10000, 'F', 'N', '1997-05-21', 402),
           (503, 'Alex', 'Hardin', '4105557648', 35000, 7500, 'M', 'N', '1998-04-09', 400),
           (508, 'Tina', 'Johnson', '4105553274', 35000, 10000, 'F', 'N', '2008-11-23', 403);

INSERT INTO Employee (employee_id, first_name, last_name, phone, salary, bonus, gender, married, hire_date, team_id, mentor_id)
    VALUES (504, 'Rachel', 'Fitzgerald', '3015559466', 35000, 5000, 'F', 'N', '2005-03-01', 400, 500),
           (505, 'Maria', 'Higgins', '4105552105', 35000, 5000, 'F', 'N', '2001-03-21', 403, 508),
           (506, 'Brian', 'Perkins', '2145554425', 35000, 5000, 'M', 'N', '2001-03-21', 400, 503),
           (507, 'Connie', 'McKinney', '4105552544', 35000, 5000, 'F', 'Y', '2001-03-21', 401, 501);

INSERT INTO Employee (employee_id, first_name, last_name, phone, salary, gender, married, hire_date, fire_date, team_id, mentor_id)
    VALUES (509, 'Travis', 'Train', '4105553512', '25000', 'M', 'N', '2004-05-31', '2004-09-30', 402, 502);


DELETE FROM InstructorCourse;
INSERT INTO InstructorCourse
    VALUES (500, 100),
           (500, 400),
           (500, 410),
           (500, 220),
           (503, 100),
           (503, 110),
           (503, 120),
           (506, 100),
           (506, 110),
           (506, 120),
           (504, 200),
           (504, 210),
           (504, 220),
           (504, 300),
           (507, 210),
           (507, 200);



DELETE FROM Team;
INSERT INTO Team
    VALUES (400, 'Education', 500),
           (401, 'Management', 501),
           (402, 'Systems', 502),
           (403, 'Sales', 508);

DELETE FROM Courseware;
INSERT INTO Courseware
    VALUES ('TE100', 'Introduction to Java','N','N','2004-12-14','2004-06-09'),
           ('TE110', 'Introduction to JSPs','N','N','2004-09-10','2004-03-24'),
           ('TE120', 'Servlet Programming','N','Y','2004-08-24','2004-02-16'),
           ('TE130', 'Servlets and JSPs','Y','N','2004-07-20','2004-01-06'),
           ('TE200', 'XHTML','N','N','2004-12-04','2004-06-09'),
           ('TE210', 'JavaScript','N','N','2004-11-12','2004-06-09'),
           ('TE220', 'Perl Programming','N','Y','2004-11-23','2004-07-21'),
           ('TE300', 'Oracle SQL','N','N','2005-01-17','2004-10-04');

DELETE FROM Customer;
INSERT INTO Customer
    VALUES (1000, 'Green Acres Farm', 'Tsa Tsa', '7025557648','Direct', 508,'August 2001'),
           (1010, 'Comical Credit Corp', 'David', '5185557499', 'Direct', 508, 'Web classes'),
           (1020, 'Beatum-Cheatam Law Services', 'Patrice', '8605552447', 'Direct', 508,'cold call'),
           (1030, 'Technical Training Services', 'Debbie', '6105553141', 'Sub', 505, 'Susan vet'),
           (1040, 'Curl Up and Dye Hair Salon', 'John', '2023337771', 'Direct', 505, 'Maria stylist');

DELETE FROM Course;
INSERT INTO Course
    VALUES (100, 'Java Programming', 500, 5, 'TE100'),
           (110, 'JSPs', 400, 2, 'TE110'),
           (120, 'Servlets', 400, 2, 'TE120'),
           (200, 'XHTML', 250, 2, 'TE200'),
           (210, 'JavaScript', 300, 3, 'TE210'),
           (220, 'Perl Programming', 400, 5, 'TE220'),
           (300, 'Oracle SQL', 500, 3, 'TE300');

INSERT INTO Course (course_id, name)
    VALUES (400, 'Fortran'),
           (410, 'PL1');


DELETE FROM Class;
INSERT INTO Class
    VALUES (5000, 1000, 200, 507, '2005-02-15', '2005-02-16', 'Las Vegas, NV', 250, 'New client'),
           (5010, 1010, 100, 503, '2005-02-14', '2005-02-18', 'NYC', 500, 'Repeat cust.'),
           (5020, 1020, 100, 506, '2005-02-14', '2005-02-18', 'Manchester, CT', 500, 'New client'),
           (5030, 1000, 210, 507, '2005-02-21', '2005-02-23', 'Las Vegas, NV', 250, '2 class disc.'),
           (5040, 1030, 220, 500, '2005-02-21', '2005-02-25', 'Columbia, MD', 400, 'Repeat cust.'),
           (5050, 1020, 300, 504, '2005-02-21', '2005-02-23', 'Manchester, CT',450, '2 class disc.'),
           (5060, 1000, 100, 503, '2005-02-28', '2005-03-04', 'Las Vegas, NV',400, '3 class disc.'),
           (5070, 1010, 110, 506, '2005-02-28', '2005-03-01', 'NYC', 350, '2 class disc.'),
           (5080, 1040, 220, 500, '2005-02-28', '2005-03-04', 'Columbia, MD', 400, 'Repeat cust.'),
           (5090, 1040, 300, 504, '2005-03-07', '2005-03-09', 'Columbia, MD', 450, '2 class disc.');
