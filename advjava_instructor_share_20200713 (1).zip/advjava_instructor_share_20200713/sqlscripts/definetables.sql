DROP TABLE IF EXISTS Employee;
CREATE TABLE Employee (
    employee_id INT,
    first_name  CHAR(10) NOT NULL,
    last_name   CHAR(10) NOT NULL,
    phone       CHAR(10),
    salary      INT DEFAULT 0,
    bonus       INT,
    gender      CHAR(1),
    married     CHAR(1),
    hire_date   DATE,
    fire_date   DATE,
    mentor_id   INT,
    team_id     INT
);


DROP TABLE IF EXISTS Course;
CREATE TABLE Course (
    course_id     INT,
    name          VARCHAR(20),
    unit_price    DECIMAL(6,2),
    num_days      INT,
    courseware_id CHAR(5)
);


DROP TABLE IF EXISTS Customer;
CREATE TABLE Customer (
    customer_id  INT,
    name         VARCHAR(30),
    contact      VARCHAR(20),
    phone        CHAR(10),
    type         VARCHAR(15),
    sales_person INT,
    comments     VARCHAR(15)
);


DROP TABLE IF EXISTS Team;
CREATE TABLE Team (
    team_id   INT,
    name      VARCHAR(15),
    leader_id INT
);


DROP TABLE IF EXISTS Class;
CREATE TABLE Class (
    class_id    INT,
    customer_id INT,
    course_id   INT,
    employee_id INT,
    start_date  DATE,
    end_date    DATE,
    location    VARCHAR(15),
    unit_price  DECIMAL(6,2),
    comments    VARCHAR(15)
);


DROP TABLE IF EXISTS InstructorCourse;
CREATE TABLE InstructorCourse (
    employee_id INT,
    course_id   INT
);


DROP TABLE IF EXISTS Courseware;
CREATE TABLE Courseware (
    courseware_id CHAR(5),
    name          VARCHAR(20),
    expired       CHAR(1),
    in_revision   CHAR(1),
    curr_rev_date DATE,
    last_rev_date DATE
);
