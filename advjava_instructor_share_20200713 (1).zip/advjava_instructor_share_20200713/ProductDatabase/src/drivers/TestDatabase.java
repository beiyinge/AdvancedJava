package drivers;

import java.util.Iterator;
import java.util.Properties;

import officesupplies.*;
import resources.ResourceLocator;

import java.io.*;

public class TestDatabase {
    public static void main (String args[]) throws Exception {

    	Properties prop = new Properties();
    	prop.load(ResourceLocator.class.getResourceAsStream("configuration.cfg"));
    	
    	Class c = Class.forName(prop.getProperty("database.class"));
    	
        Database pf = (Database) c.newInstance();
        if (! pf.open()) {
            System.err.println ("Error reading products file!");
            System.exit (-2);
        }
        
        Product aProduct;
        
        //  Display all the products

        Iterator<Product> it = pf.values().iterator();
        while (it.hasNext()) {
            aProduct = it.next();
            System.out.println (aProduct);
        }

        //  Display selected products

        BufferedReader br = new BufferedReader 
                                (new InputStreamReader (System.in));
        String productId = "";
        while (true) {
            System.out.print ("Enter product id (or 'quit'): ");
            productId = br.readLine();
            if (productId.equalsIgnoreCase ("quit")) {
                break;
            }
            aProduct = pf.get (productId);
            if (aProduct == null) {
                System.out.println (productId + " not found");
            } else {
                System.out.println (aProduct);
            }
        }
    }
}
