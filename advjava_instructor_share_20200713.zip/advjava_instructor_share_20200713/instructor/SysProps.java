package instructor;

import java.util.Map;
import java.util.Properties;

public class SysProps {
	public static void main(String[] args) {
		Properties p = System.getProperties();
		for(Map.Entry me : p.entrySet()) {
			System.out.printf("Key:%s%n\tValue:%s%n", me.getKey(), me.getValue());
		}
		
	}
}
