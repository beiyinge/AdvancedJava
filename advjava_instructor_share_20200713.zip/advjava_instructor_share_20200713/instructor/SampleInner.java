package instructor;

import java.util.Arrays;
import java.util.Comparator;

public class SampleInner {
	
	
	
	public static void main(String[] args) {
		String names [] = {"Bob", "Sue", "billy", "Anthony", "alice", "Zoey"};
		Arrays.sort(names);
		System.out.println(Arrays.toString(names));
		
		Arrays.sort(names, new Comparator() {

			@Override
			public int compare(Object o1, Object o2) {
				int s1 = ((String) o1).length();
				int s2 = ((String) o2).length();
				int result =  Integer.valueOf(s1).compareTo(s2);
				if(result == 0) {
					result = new Alphabetical().compare(o2, o1);
				}
				
				return result;     
				
			}});
		System.out.println(Arrays.toString(names));
		
		Arrays.sort(names, new Alphabetical());
		System.out.println(Arrays.toString(names));
	}
	
	
	static class Alphabetical implements Comparator{

		@Override
		public int compare(Object o1, Object o2) {
			String s1 = ((String) o1).toLowerCase();
			String s2 = ((String) o2).toLowerCase();
			return s1.compareTo(s2);
		}
		
	}
	
	
}

