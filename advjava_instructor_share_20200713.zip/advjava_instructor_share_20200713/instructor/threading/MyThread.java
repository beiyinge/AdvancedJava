package instructor.threading;
public class MyThread extends Thread {
    public MyThread(String s) {
        super(s);
    }
    public void run() {
        for(int i = 0; i < 5; i++){
            System.out.println(getName() + " " + i);
        }
    }
    public static void main(String a[]) {
    	long start = System.currentTimeMillis();
        MyThread threads [] = { new MyThread("Thread A"),
        		                new MyThread("Thread B"),
        		                new MyThread("Thread c"),
        		                new MyThread("Thread d"),
        		                new MyThread("Thread e"),
        		                new MyThread("Thread f"),
        		                new MyThread("Thread g")
        };
        for (Thread t : threads) {
        	t.start();
        }
        for (int i = 0; i < 5; i++)
          System.out.println("MainThread " + i);
        
        for(Thread t :threads) {
	        try {
				t.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        long end = System.currentTimeMillis();
        System.out.println(end - start + " Milliseconds");
    }
}