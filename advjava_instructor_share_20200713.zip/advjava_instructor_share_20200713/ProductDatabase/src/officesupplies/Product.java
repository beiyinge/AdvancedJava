package officesupplies;

public class Product implements java.io.Serializable, Comparable<Product> {
    

	private static final long serialVersionUID = 1L;

	protected String id;                //  Unique key value for each product
    protected String description;
    protected String unitOfMeasure;
    protected double unitPrice;
    protected int    qtyOnHand;         //  Qty available to be shipped
    protected int    qtyOrdered;        //  Qty ordered, but not shipped

    public Product() { }

    

    public Product(String id, String description, String unitOfMeasure, double unitPrice, int qtyOnHand,
			int qtyOrdered) {
		this.id = id;
		this.description = description;
		this.unitOfMeasure = unitOfMeasure;
		this.unitPrice = unitPrice;
		this.qtyOnHand = qtyOnHand;
		this.qtyOrdered = qtyOrdered;
	}



	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public String getUnitOfMeasure() {
		return unitOfMeasure;
	}



	public void setUnitOfMeasure(String unitOfMeasure) {
		this.unitOfMeasure = unitOfMeasure;
	}



	public double getUnitPrice() {
		return unitPrice;
	}



	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}



	public int getQtyOnHand() {
		return qtyOnHand;
	}



	public void setQtyOnHand(int qtyOnHand) {
		this.qtyOnHand = qtyOnHand;
	}



	public int getQtyOrdered() {
		return qtyOrdered;
	}



	public void setQtyOrdered(int qtyOrdered) {
		this.qtyOrdered = qtyOrdered;
	}



	/**
    *   Add the specified amount (may be negative) to qty on hand
    *   and return the updated qty
    */
    
    public int updateQtyOnHand (int amt) {
    	return qtyOnHand += amt;
    }
    
    /**
    *   Add the specified amount (may be negative) to qty ordered
    *   and return the updated qty
    */
    
    public int updateQtyOrdered (int amt) {
    	return qtyOrdered += amt;
    }


    
    /**
    *   Return a string representation of all of the product data
    */
	@Override
	public String toString() {
		String fmt = "%s, %s, %s, %s, %s, %s";
		return String.format(fmt, id, description,unitOfMeasure,
				                 unitPrice, qtyOnHand, qtyOrdered);
	}



	@Override
	public int compareTo(Product p) {
		return this.id.compareTo(p.id);
	}

    
}


