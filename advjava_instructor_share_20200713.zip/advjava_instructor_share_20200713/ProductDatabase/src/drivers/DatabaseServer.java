package drivers;

import java.util.Iterator;
import java.util.Properties;

import officesupplies.*;
import resources.ResourceLocator;

import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class DatabaseServer {
    public static void main (String args[]) throws Exception {

    	Properties prop = new Properties();
    	prop.load(ResourceLocator.class.getResourceAsStream("configuration.cfg"));
    	
    	Class c = Class.forName(prop.getProperty("database.class"));
    	
        Database pf = (Database) c.newInstance();
        if (! pf.open()) {
            System.err.println ("Error reading products file!");
            System.exit (-2);
        }
        startServer(pf);
        pf.close();
    }
    public static void startServer(Database db) {
        ServerSocket theServer = null;
        Socket clientSocket;
        int port = 4567;
        InetAddress ia = null;
        // Attempt to start the server
        // bound to the given port
        try{
            theServer = new ServerSocket(port);
            // Print info about the server
            ia = InetAddress.getLocalHost();
            String host = ia.getHostAddress();
            System.out.println("Server started on " +
                host+ "  Listening on port "+ port);
            // loop for each client
            while(true){
                // wait for a client to connect
                clientSocket = theServer.accept();
                // handle client in a helper method
                System.out.println("connection from: " +clientSocket);
                handleClient(clientSocket, db);
            } // proceed to next Client
        } catch(IOException ioe){
            ioe.printStackTrace();
            System.exit(1);
        }
    }
    
    
    // Helper method to handle client communications
    private static void handleClient(Socket cSocket, Database db){
        ObjectOutputStream toClient;
        BufferedReader fromClient;
        String data;
        try{
            // Get Input and Output
            fromClient = new BufferedReader(
                new InputStreamReader(
                    cSocket.getInputStream()));
            toClient = new ObjectOutputStream(
                cSocket.getOutputStream());
            while(true){
                // read from Client
                data = fromClient.readLine();
                if(data == null) break;
                Product p = db.get(data);
                // write to Client
                toClient.writeObject(p);
            }
            fromClient.close();
            toClient.close();
            cSocket.close();
        }catch(IOException ioe){
            String msg = "Connection lost";
            System.out.println(msg);
        }
    }
    
}
