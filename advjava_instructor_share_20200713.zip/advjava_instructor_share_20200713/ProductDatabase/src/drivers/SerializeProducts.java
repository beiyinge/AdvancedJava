package drivers;

import java.util.Iterator;
import java.util.Properties;

import officesupplies.Database;
import officesupplies.Product;
import officesupplies.ProductDBFromFile;
import resources.ResourceLocator;

import java.io.*;
import java.net.URI;

public class SerializeProducts {
    public static void main (String args[]) throws Exception {

        Database pf = new ProductDBFromFile();
        if (! pf.open()) {
            System.err.println ("Error reading products file!");
            System.exit (-2);
        }
        
        Product aProduct;
        Properties prop = new Properties();
    	prop.load(ResourceLocator.class.getResourceAsStream("configuration.cfg"));
        //  serialize all the products
        URI uri = ResourceLocator.class.getResource("").toURI();
        File f = new File(uri);
        f = new File(f, prop.getProperty("serfile.name"));
        ObjectOutputStream oos;
        oos = new ObjectOutputStream(new FileOutputStream(f));
        
        Iterator<Product> it = pf.values().iterator();
        while (it.hasNext()) {
            aProduct = it.next();
            oos.writeObject(aProduct);
        }
        oos.close();
      
    }
}
